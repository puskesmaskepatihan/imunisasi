require('dotenv').config();
const { MongoClient } = require('mongodb');
const dayjs = require('dayjs');
const cron = require('node-cron');
const twilio = require('twilio');

const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const fromWhatsApp = process.env.TWILIO_WHATSAPP_FROM;

async function sendWhatsApp(to, message) {
  try {
    await twilioClient.messages.create({
      from: fromWhatsApp,
      to: `whatsapp:${to}`,
      body: message,
    });
    console.log(`Pesan terkirim ke ${to}`);
  } catch (err) {
    console.error('Error mengirim WhatsApp:', err);
  }
}

async function checkAndSendReminders() {
  try {
    await client.connect();
    const db = client.db('imunisasiDB');
    const collection = db.collection('children');

    const todayStr = dayjs().format('YYYY-MM-DD');

    const children = await collection.find({}).toArray();

    for (const child of children) {
      for (const schedule of child.schedule) {
        const schedDate = dayjs(schedule.date).format('YYYY-MM-DD');
        if (schedDate === todayStr) {
          const msg = `Halo ${child.name}, hari ini jadwal imunisasi: ${schedule.name}. Jangan lupa datang ya! 😊`;
          await sendWhatsApp(child.phone, msg);
        }
      }
    }
  } catch (err) {
    console.error('Error di checkAndSendReminders:', err);
  } finally {
    await client.close();
  }
}

cron.schedule('0 8 * * *', () => {
  console.log(`[${new Date().toISOString()}] Menjalankan pengecekan imunisasi harian...`);
  checkAndSendReminders();
});