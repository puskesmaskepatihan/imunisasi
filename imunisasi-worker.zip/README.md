# Imunisasi Reminder Worker

Worker script ini akan mengecek jadwal imunisasi harian dari MongoDB dan mengirimkan pesan WhatsApp ke orang tua menggunakan Twilio API.

## Cara Pakai

1. Clone repo ini
2. Buat file `.env` berdasarkan `.env.example`
3. Jalankan dengan:

```bash
npm install
node reminder-worker.js
```

Atau gunakan `pm2` untuk menjalankan di background:

```bash
npm install -g pm2
pm2 start reminder-worker.js
```

Pesan akan dikirim setiap hari jam 08:00 WIB (waktu server).